<?php
// Set refresh rate to 0.5 seconds
$refresh = 0.5;

/*
  Rui Santos
  Complete project details at https://RandomNerdTutorials.com/esp32-esp8266-mysql-database-php/
  
  Permission is hereby granted, free of charge, to any person obtaining a copy
  of this software and associated documentation files.
  
  The above copyright notice and this permission notice shall be included in all
  copies or substantial portions of the Software.
*/

$servername = "localhost";

// REPLACE with your Database name
$dbname = "u497569487_monitoring";
// REPLACE with Database user
$username = "u497569487_monitoring";
// REPLACE with Database user password
$password = "Eugenian2206";

// Keep this API Key value to be compatible with the ESP32 code provided in the project page. 
// If you change this value, the ESP32 sketch needs to match
$api_key_value = "tPmAT5Ab3j7F9";

$api_key= $sensor = $location = $value1 = $value2 = $value3 = $value4 = $value5 = $value6 = $value7 = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $api_key = test_input($_POST["api_key"]);
    if($api_key == $api_key_value) {
       
        $value1 = test_input($_POST["value1"]);
        $value2 = test_input($_POST["value2"]);
        $value3 = test_input($_POST["value3"]);
        $value4 = test_input($_POST["value4"]);
        $value5 = test_input($_POST["value5"]);
        $value6 = test_input($_POST["value6"]);
        $value7 = test_input($_POST["value7"]);
        
        ?>

<!DOCTYPE html>
<html>
<head>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="icon" href="data:,">
    <meta http-equiv="refresh" content="<?php echo $refresh; ?>"/>
    
    <!-- CSS to style the table -->
    <style>
        body { text-align: center; font-family: "Trebuchet MS", Arial; }
        table { border-collapse: collapse; width:35%; margin-left:auto; margin-right:auto; }
        th { padding: 12px; background-color: #0043af; color: white; }
        tr { border: 1px solid #ddd; padding: 12px; }
        tr:hover { background-color: #bcbcbc; }
        td { border: none; padding: 12px; }
        .sensor { color:white; font-weight: bold; background-color: #bcbcbc; padding: 1px; }
    </style>
</head>
<body>
 
    <h1>Edelsmafa</h1>
    <table>
        <tr><th> Hurudza Readings </th><th>VALUE</th></tr>
        <tr><td>Nitrogen N: </td><td><span class="sensor"><?php echo $value1; ?> mg/kg</span></td></tr>
        <tr><td>Phosphorus P: </td><td><span class="sensor"><?php echo $value2; ?> mg/kg </span></td></tr>
        <tr><td>Potasium K: </td><td><span class="sensor"><?php echo $value3; ?> mg/kg </span></td></tr>
        <tr><td>soil_ph pH: </td><td><span class="sensor"><?php echo $value4/10; ?> </span></td></tr>
        <tr><td>soil_Humidity M: </td><td><span class="sensor"><?php echo $value5/10; ?> %</span></td></tr>
        <tr><td>soil_temp T: </td><td><span class="sensor"><?php echo $value6/10; ?> *C</span></td></tr>
        <tr><td>soil_ctvt EV: </td><td><span class="sensor"><?php echo $value7; ?> us/cm </span></td></tr>
    </table>
</body>
</html>
        
        
        <?php
        // Create connection
        $conn = new mysqli($servername, $username, $password, $dbname);
        // Check connection
        if ($conn->connect_error) {
            die("Connection failed: " . $conn->connect_error);
        } 
        
        $sql = "INSERT INTO SensorData (value1, value2, value3, value4, value5, value6, value7)
        VALUES ('" . $value1 . "', '" . $value2 . "', '" . $value3 . "', '" . $value4 . "', '" . $value5 . "', '" . $value6 . "', '" . $value7 . "')";
        
        if ($conn->query($sql) === TRUE) {
            echo "New record created successfully";
        } 
        else {
            echo "Error: " . $sql . "<br>" . $conn->error;
        }
    
        $conn->close();
    }
    else {
        echo "Wrong API Key provided.";
    }

}
else {
    echo "No data posted with HTTP POST.";
}

function test_input($data) {
    $data = trim($data);
    $data = stripslashes($data);
    $data = htmlspecialchars($data);
    return $data;
}